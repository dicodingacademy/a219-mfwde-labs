const contacts = [
  {
    id: '1594278815776',
    name: 'John Doe',
    type: 'mobile',
    number: '+62-8923-12xx',
  },
  {
    id: '1594278841362',
    name: 'Jane Doe',
    type: 'office',
    number: '+62-211xx',
  },
  {
    id: '1594278889481',
    name: 'Harry Potter',
    type: 'mobile',
    number: '+62-8131-13xx'
  },
];

export default contacts;
