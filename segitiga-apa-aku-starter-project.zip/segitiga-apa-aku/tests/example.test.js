const yourName = 'Judy Doe';

describe('Scenario Test Example', () => {
  it('test case example', () => {
    expect(yourName).toEqual('John Doe');
  });
});
